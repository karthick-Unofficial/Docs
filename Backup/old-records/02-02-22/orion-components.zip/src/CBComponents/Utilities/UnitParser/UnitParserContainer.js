import { connect } from "react-redux";
import UnitParser from "./UnitParser";
const mapStateToProps = (state, props) => {
	const { unitsOfMeasurement } = state.appState.global;
	return { unitsOfMeasurement };
};

const UnitParserContainer = connect(mapStateToProps)(UnitParser);

export default UnitParserContainer;
