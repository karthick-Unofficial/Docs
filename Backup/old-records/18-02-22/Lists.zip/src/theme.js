const theme = {
	palette: {
		primary: {
			main: "#35b7f3"
		}
	}
};

export default theme;
