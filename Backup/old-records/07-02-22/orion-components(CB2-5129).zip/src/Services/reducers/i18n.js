import { i18nReducer } from "react-redux-i18n";

const i18nRootReducer = (i18nReducer);
export default i18nRootReducer;