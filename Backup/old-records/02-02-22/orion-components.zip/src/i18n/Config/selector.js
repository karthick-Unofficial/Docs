export function getDir(state) {
	return state.i18n.locale === "ar" ? "rtl" : "ltr";
}