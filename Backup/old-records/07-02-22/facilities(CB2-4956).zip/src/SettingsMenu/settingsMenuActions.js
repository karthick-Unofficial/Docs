import * as t from "./actionTypes";

export const closeSettingsMenu = () => {
	return {
		type: t.SETTINGS_MENU_CLOSE
	};
};
