import * as t from "./actionTypes";

export const servicesReady = () => {
	return {
		type: t.SERVICES_READY
	};
};