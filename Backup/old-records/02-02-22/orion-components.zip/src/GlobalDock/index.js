export { default as GlobalDock } from "./GlobalDockContainer";
export { openPanel, closePanel } from "./dockActions";