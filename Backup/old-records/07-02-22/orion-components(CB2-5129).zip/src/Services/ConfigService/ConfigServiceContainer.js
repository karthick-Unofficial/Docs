import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as actionCreators from "./actions.js";
import ConfigService from "./ConfigService";


const mapDispatchToProps = dispatch => {
	return bindActionCreators(actionCreators, dispatch);
};

const ConfigServiceContainer = connect(
	null,
	mapDispatchToProps
)(ConfigService);

export default ConfigServiceContainer;
