// import React from "react";
// import RulesAppBar from "./RulesAppBar";
// import renderer from "react-test-renderer";

// import { shallow } from "enzyme";

// jest.mock("mapbox-gl/dist/mapbox-gl", () => ({
// 	Map: () => ({})
// }));

// FIXME: Figure out what is causing the Enzyme error and fix it, then add test back.
// See conditionDialog.test.js for more information about the error.
it("renders", () => {
	// const user = { isHydrated: true, profile: {} };

	// const wrapper = shallow(<RulesAppBar user={user} />);
	// expect(wrapper).toMatchSnapshot();

	return new Promise(resolve => {
		resolve();
	});
});
