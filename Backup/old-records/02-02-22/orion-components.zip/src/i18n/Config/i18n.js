export const supportedLocales = {
	en: "English",
	ar: "عربي"
};

export const fallbackLocale = "en";