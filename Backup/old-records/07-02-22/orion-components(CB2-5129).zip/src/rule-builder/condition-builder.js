import React from "react";
import moment from "moment-timezone";
import { timeConversion } from "client-app-core";
import _ from "lodash";
const getConditions = (rule, collections, targetAction, hasLinks) => {
	if (rule.conditions.length === 0) {
		return "";
	} else {
		const abort = false;
		let andString = "";
		const timeFormatPreference = rule.timeFormatPreference ? rule.timeFormatPreference : "12-hour";

		// Render conditions portion of rule statement
		const conditions = rule.conditions.map((cond, index) => {
			switch (cond.type) {
				case "time": {
					const startTime = moment.utc(cond.startTime, "h:mm A");
					const endTime = moment.utc(cond.endTime, "h:mm A");

					const timeFormat = timeFormatPreference === "24-hour" ? "H:mm z" : "h:mm A z";
					const startTimeTZ = timeConversion.convertToUserTime(startTime, timeFormat);
					const endTimeTZ = timeConversion.convertToUserTime(endTime, timeFormat);

					let finalString = "";

					if (cond.anyTimeOfDay) {
						finalString += "";
					} else {
						finalString += ` it is between ${startTimeTZ} and ${endTimeTZ}`;
					}

					if (cond.weekdays.length === 7) {
						finalString += "";
					} else {
						if (finalString.length === 0) {
							finalString += " it is";
						}
						const days = [
							"Sunday",
							"Monday",
							"Tuesday",
							"Wednesday",
							"Thursday",
							"Friday",
							"Saturday"
						];
						finalString += cond.weekdays
							.map(
								(index, i) =>
									(i === cond.weekdays.length && i > 1 ? " or " : " ") +
									days[index]
							)
							.join(",");
					}

					if (cond.indefinite) {
						finalString += "";
					} else {
						const startDate = timeConversion.convertToUserTime(
							cond.startDate,
							"ll"
						);
						const endDate = timeConversion.convertToUserTime(
							cond.endDate,
							"ll"
						);
						if (cond.weekdays.length && cond.weekdays.length !== 7) {
							finalString += " AND ";
						}
						finalString +=
							startDate === endDate
								? ` the date is ${startDate}`
								: ` is during the period of ${startDate} and ${endDate}`;
					}

					finalString += "";
					andString = " AND ";
					return finalString;
				}
				case "speed": {
					const conditions = [];
					if (cond.minSpeed) {
						const minSpeed = ` is traveling slower than ${cond.minSpeed} ${
							cond.unit
						}`;
						conditions.push(minSpeed);
					}
					if (cond.maxSpeed) {
						const maxSpeed = ` is traveling faster than ${cond.maxSpeed} ${
							cond.unit
						}`;
						conditions.push(maxSpeed);
					}
					andString = " AND ";
					return conditions.join(" or ");
				}

				case "in-collection": {
					const collection = _.find(collections, col => col.id === cond.id);
					if (!collection) {
						return "";
					}
					const collectionName = collection.name;
					andString = " AND ";
					return ` is in the collection ${collectionName} `;
				}

				case "not-in-collection": {
					const collection = _.find(collections, col => col.id === cond.id);
					if (!collection) {
						return "";
					}
					const collectionName = collection.name;
					andString = " AND ";
					return ` is not in the collection ${collectionName} `;
				}
				case "duration": {
					const duration = cond.duration;
					return duration === 1
						? ` for longer than ${duration} minute`
						: ` for longer than ${duration} minutes`;
				}
				default:
					break;
			}
		});

		return conditions.map((condition, index) => {
			if (!condition) {
				return null;
			}
			return (
				<div key={condition} className="rule-statement-container">
					<span className="and-string">{andString}</span>
					<span>{condition}</span>
				</div>
			);
		});
	}
};

export default getConditions;
