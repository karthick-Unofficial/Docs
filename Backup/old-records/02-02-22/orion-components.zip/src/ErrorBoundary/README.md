[TOC]

# ErrorBoundary

## Overview

ErrorBoundary is a custom implementation of React 16's ErrorBoundary. 

## Usage

Wrap the Container you want to catch errors for in an ErrorBoundary. For more information, see React's docs: 
https://reactjs.org/blog/2017/07/26/error-handling-in-react-16.html

