import React from "react";
import { withSpan } from "../../../Apm"; 
import PropTypes from "prop-types";
import { FontIconButton } from "orion-components/CBComponents";
import { TargetingIcon, getIcon, getIconByTemplate } from "orion-components/SharedComponents";
import {
	IconButton,
	ListItem,
	ListItemIcon,
	ListItemText
} from "@material-ui/core";
import { MoreHoriz } from "@material-ui/icons";
import getButtons from "./getButtons";
import getAction from "./getAction";
import _ from "lodash";
import { Translate } from "orion-components/i18n/I18nContainer";

const propTypes = {
	context: PropTypes.object.isRequired,
	id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
	user: PropTypes.object.isRequired,
	name: PropTypes.string,
	displayType: PropTypes.string,
	type: PropTypes.string,
	description: PropTypes.string,
	geometry: PropTypes.oneOfType([PropTypes.object, PropTypes.bool]),
	actions: PropTypes.array,
	scrolledUp: PropTypes.bool,
	handleExpand: PropTypes.func,
	mapVisible: PropTypes.bool,
	isHiding: PropTypes.bool,
	profileIconTemplate: PropTypes.string,
	dir: PropTypes.string
};

const defaultProps = {
	name: "",
	displayType: "",
	type: "",
	description: "",
	geometry: null,
	actions: null,
	scrolledUp: false,
	handleExpand: null,
	mapVisible: false,
	isHiding: false,
	profileIconTemplate: null,
	dir: "ltr"
};

const SummaryWidget = ({
	context,
	id,
	user,
	name,
	displayType,
	type,
	description,
	geometry,
	actions,
	scrolledUp,
	handleExpand,
	mapVisible,
	isHiding,
	appId,
	profileIconTemplate,
	readOnly,
	dir
}) => {
	const { entity } = context;
	const { ownerName, feedId } = entity;
	const buttons = getButtons(user, context, appId, actions, readOnly);
	if (buttons) {
		buttons.map(button => {
			actions.forEach(action => {
				if (action.name === button.name) {
					button.action = action.action;
				}

				// Prevents multiple simultaneous clicks 
				// On-click, set flag in parent profile, pass down as action.debounce
				if (action.debounce) {
					button.disabled = true;
				}
			});
			if (!button.action) {
				button.viewable = false;
			}
			return button;
		});
	}

	return (
		<div className={`summary-wrapper ${scrolledUp ? "scrolled-up" : ""} `}>
			<ListItem className="summary-info" disableGutters>
				{geometry && (
					<TargetingIcon id={id} feedId={feedId} geometry={geometry || null} />
				)}
				{type && getIconByTemplate(type, entity, "2rem", profileIconTemplate) && (
					<ListItemIcon
						style={dir == "rtl" ? {
							marginLeft: 0,
							marginRight: !geometry || !mapVisible ? 12 : 0,
							color: "#828283",
							fontSize: "2rem"
						} : {
							marginRight: 0,
							marginLeft: !geometry || !mapVisible ? 12 : 0,
							color: "#828283",
							fontSize: "2rem"
						}}
					>
						{getIconByTemplate(type, entity, "2rem", profileIconTemplate)}
					</ListItemIcon>
				)}
				<ListItemText className={` ${scrolledUp ? "MuiTypography-noWrap" : ""}`}
					primary={_.toUpper(name || id)}
					secondary={
						ownerName
							? <Translate value="global.profiles.widgets.summary.createdBy" primaryValue={displayType || type} secondaryValue={ownerName}/>
							: displayType || type
					}
					primaryTypographyProps={{
						style: {
							color: "#FFF",
							lineHeight: 1,
							textOverflow: "ellipsis",
							overflow: "hidden",
							wordWrap: "break-word"
						},
						variant: "h6"
					}}
					secondaryTypographyProps={{
						style: { color: "#828283" },
						noWrap: scrolledUp
					}}
				/>
				{scrolledUp && (buttons || description) && (
					<IconButton onClick={handleExpand}>
						<MoreHoriz style={{ color: "#FFF" }} />
					</IconButton>
				)}
			</ListItem>

			{!scrolledUp && (buttons || description) && (
				<div style={{ padding: "0 10px" }}>
					<div className="summary-description">
						<p>{description}</p>
					</div>
					<div
						style={{
							display: "flex",
							alignItems: "flex-start",
							justifyContent: "flex-end",
							flexWrap: "nowrap"
						}}
					>
						{buttons &&
							buttons
								.filter(button => {
									return button.viewable;
								})
								.map(button => {
									const { name, toggled, disabled, action, icon } = button;
									return (
										<FontIconButton
											key={name}
											label={name}
											icon={icon}
											action={action}
											toggled={toggled}
											disabled={disabled}
										/>
									);
								})}
						{entity.actions &&
							entity.actions.map(action => {
								const { label, type } = action;
								return (
									<FontIconButton
										key={label}
										label={label}
										icon={getIcon(type, 24)}
										action={getAction(action)}
									/>
								);
							})}
					</div>
				</div>
			)}
		</div>
	);
};

SummaryWidget.propTypes = propTypes;
SummaryWidget.defaultProps = defaultProps;

export default withSpan("summary-widget", "profile-widget")(SummaryWidget);
