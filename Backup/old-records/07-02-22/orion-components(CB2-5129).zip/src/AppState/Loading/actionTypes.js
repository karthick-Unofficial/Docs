export const SET_LOADING = "SET_LOADING";
export const TOGGLE_LOADING = "TOGGLE_LOADING";
