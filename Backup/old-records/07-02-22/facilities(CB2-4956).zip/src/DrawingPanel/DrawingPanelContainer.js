import { connect } from "react-redux";
import DrawingPanel from "./DrawingPanel.jsx";
import { getDir } from "orion-components/i18n/Config/selector";

const mapStateToProps = state => {
	const { mode, type } = state.mapState.mapTools;
	return { mode, type, dir: getDir(state) };
};

const DrawingPanelContainer = connect(mapStateToProps)(DrawingPanel);

export default DrawingPanelContainer;
