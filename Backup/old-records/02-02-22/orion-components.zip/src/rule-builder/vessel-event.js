import React from "react";
import _getConditions from "./condition-builder.js";

const vesselEventBuilder = (
	rule,
	collections
) => {
	return(
		<div id="rule-statement" className="cb-font-b9">
			Alert me when {_getMain(rule, collections)}
			{_getTargets(rule, collections)}
			{_getConditions(rule, collections)}
		</div>
	);
};

const _getMain = (rule, collections) => {
	let main = "";
	
	switch (rule.trigger) {
		case "berth-assignment-created":
			main = "a new berth request is created";
			break;
		case "berth-assignment-approval":
			main = "a berth request is approved";
			break;
		case "berth-assignment-update":
			main = "an assignment is updated";
			break;
		case "arrival":
			main = "there is an arrival";
			break;
		case "departure":
			main = "there is a departure";
			break;
		case "berth-security-violation":
			main = "there is a security violation";
			break;
		default:
			break;
	}

	return main;
};

const _getTargets = (rule, collections) => {
	if (rule.targets.length === 0) {
		return "";
	} else {
		return rule.targets.map((berth, index) => {
			return (
				<span key={berth.id} className="rule-statement-container">
					{index === 0 && <span>{rule.trigger === "berth-assignment-update" ? " for " : " at "}</span>}
					{index > 0 && <span>{" or "}</span>}
					<span>
						{berth.name}
					</span>
				</span>
			);
		});
	}
};

export default vesselEventBuilder;