import React, { useEffect, useState } from "react";
import { TableHead, TableCell, Table, TableRow, TableBody, TableContainer } from "@material-ui/core";
import _ from "lodash";
import { Translate } from "orion-components/i18n/I18nContainer";


const WidgetTable = ({
    tableData,
    WidgetType,
    expanded,
    dir
}) => {
    const style = {
        cell: {
            color: "#D5D7D7",
            borderBottom: "1px solid #969AA0",
        },
        cellRTL: {
            color: "#D5D7D7",
            borderBottom: "1px solid #969AA0",
            textAlign: "right"
        }
    }
    const [tableHeader, setTableheader] = useState([]);
    const [widgetData, setWidgetData] = useState([]);


    useEffect(() => {
        if (WidgetType === "resources") {
            setTableheader(
                [
                    {
                        header: <Translate value="global.profiles.widgets.hrms.widgetTable.name" />
                    },
                    {
                        header: <Translate value="global.profiles.widgets.hrms.widgetTable.rank" />
                    },
                    {
                        header: <Translate value="global.profiles.widgets.hrms.widgetTable.location" />
                    },
                    {
                        header: <Translate value="global.profiles.widgets.hrms.widgetTable.unit" />
                    },


                ]);
        }
        else {

            setTableheader([
                {
                    header: <Translate value="global.profiles.widgets.hrms.widgetTable.name" />
                },
                {
                    header: <Translate value="global.profiles.widgets.hrms.widgetTable.category" />
                },
                {
                    header: <Translate value="global.profiles.widgets.hrms.widgetTable.unit" />
                }
            ]);
        }
        tableData.sort((a, b) => a.Name.localeCompare(b.Name));
        setWidgetData(tableData);
    }, [WidgetType, tableData]);


    return (
        <div>
            {widgetData.length > 0 ?
                <div>
                    <TableContainer style={{ maxHeight: expanded ? "auto" : "100px", overflow: !expanded ? "hidden" : "auto" }}>
                        <Table>
                            <colgroup>
                                {tableHeader.map((row, index) => {
                                    return (
                                        <col width="34%" key={index} />
                                    );
                                })}
                            </colgroup>
                            <TableHead>
                                <TableRow>
                                    {tableHeader.map((value, index) => {
                                        return (
                                            <TableCell
                                                style={{
                                                    position: "sticky",
                                                    color: "#969AA0",
                                                    backgroundColor: expanded ? "#35383C" : "#2C2D2F"
                                                }}
                                                key={index} >
                                                {value.header}
                                            </TableCell>
                                        );
                                    })}

                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {WidgetType === "resources" ? widgetData.map((element, index) => {
                                    return (
                                        <TableRow key={index} tabIndex="0" id="widgetScrollResource">
                                            <TableCell style={dir == "rtl" ? style.cellRTL : style.cell}>{element.Name}</TableCell>
                                            <TableCell style={dir == "rtl" ? style.cellRTL : style.cell}>{element.RankName}</TableCell>
                                            <TableCell style={dir == "rtl" ? style.cellRTL : style.cell}>{element.LocationName}</TableCell>
                                            <TableCell style={dir == "rtl" ? style.cellRTL : style.cell}>{element.UnitName}</TableCell>
                                        </TableRow>
                                    )

                                }) :
                                    widgetData.map((element, index) => {
                                        return (
                                            <TableRow key={index} tabIndex="0" id="widgetScrollEquipment">
                                                <TableCell style={dir == "rtl" ? style.cellRTL : style.cell}>{element.Name}</TableCell>
                                                <TableCell style={dir == "rtl" ? style.cellRTL : style.cell}>{element.Category}</TableCell>
                                                <TableCell style={dir == "rtl" ? style.cellRTL : style.cell}>{element.UnitName}</TableCell>
                                            </TableRow>
                                        )

                                    })}

                            </TableBody>
                        </Table>
                    </TableContainer>
                </div>
                : <div />}
        </div>
    );
};
export default WidgetTable;