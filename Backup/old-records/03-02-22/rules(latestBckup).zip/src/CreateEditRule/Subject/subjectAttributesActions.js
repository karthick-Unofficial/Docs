
import * as t from "../../actionTypes";


export const clearSearchResults = () => {
	return {
		type: t.CLEAR_SEARCH_RESULTS
	};
};
