export { default as RobotDogBluePrint } from "./robot-dog-blueprint.png";
