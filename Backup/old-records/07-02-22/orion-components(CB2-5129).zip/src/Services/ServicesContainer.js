import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as actionCreators from "./servicesActions.js";
import Services from "./Services";


const mapDispatchToProps = dispatch => {
	return bindActionCreators(actionCreators, dispatch);
};

const ServicesContainer = connect(
	null,
	mapDispatchToProps
)(Services);

export default ServicesContainer;
