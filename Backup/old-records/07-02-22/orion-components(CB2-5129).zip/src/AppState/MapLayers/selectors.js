import { createSelector } from "reselect";

export const mapLayersState = state => state.appState.mapLayers;
