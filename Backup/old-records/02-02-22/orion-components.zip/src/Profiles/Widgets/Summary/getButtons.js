const getButtons = (user, context, appId, actions, readOnly) => {
	const { applications } = user;
	const { entity, trackHistory } = context;
	const { isPublic, entityType, fov, activeFOV, entityData, sharedWith } = entity;
	const hasReports = applications.find(app => app.appId === "reports-app");

	switch (entityType) {
		case "track":
			return [
				{
					name: "Track History",
					icon: "history",
					toggled: !!trackHistory,
					viewable: true
				},
				{
					name: "Pin To",
					icon: "star",
					toggled: false,
					viewable: !readOnly
				},
				{
					name: "Hide",
					icon: "delete",
					toggled: false,
					viewable: !readOnly
				}
			];
		case "shapes":
			return [
				{
					name: "Pin To",
					icon: "star",
					toggled: false,
					viewable: !readOnly
				},
				{
					name: "Edit",
					icon: "edit",
					toggled: false,
					viewable:
						!readOnly && 
						appId !== "cameras-app" &&
						user.integrations
						&& user.integrations.find(int => int.intId === entity.feedId)
						&& user.integrations.find(int => int.intId === entity.feedId).permissions
						&& user.integrations.find(int => int.intId === entity.feedId).permissions.includes("manage")
				},
				{
					name: "Delete",
					icon: "delete",
					toggled: false,
					viewable: !readOnly 
						&& user.integrations
						&& user.integrations.find(int => int.intId === entity.feedId)
						&& user.integrations.find(int => int.intId === entity.feedId).permissions
						&& user.integrations.find(int => int.intId === entity.feedId).permissions.includes("manage")
				},
				{
					name: "Hide",
					icon: "delete",
					toggled: false,
					viewable: !readOnly && isPublic
				}
			];
		case "camera": {
			const buttons = [];
			if (appId && appId.toLowerCase() === "cameras-app") {
				let facilityHidden = true;
				actions.some(action => {
					if (action.name.toLowerCase() === "facility") {
						facilityHidden = false;
						return true;
					} else {
						return false;
					}
				});
				buttons.push({
					name: "Facility",
					viewable: !readOnly && entityData.displayType && entityData.displayType.toLowerCase() === "facility" && entityData.displayTargetId,
					icon: "homework",
					disabled: facilityHidden
				});
			}
			return [
				...buttons,
				{
					name: activeFOV ? "Hide FOV" : "Show FOV",
					icon: "network_wifi",
					toggled: activeFOV,
					viewable: fov && activeFOV !== undefined
				},
				{
					name: "Pin To",
					icon: "star",
					toggled: false,
					viewable: !readOnly
				},
				{
					name: "Edit",
					icon: "edit",
					toggled: false,
					viewable: !readOnly && user.integrations
						&& user.integrations.find(int => int.intId === entity.feedId)
						&& user.integrations.find(int => int.intId === entity.feedId).permissions
						&& user.integrations.find(int => int.intId === entity.feedId).permissions.includes("manage")
				},
				{
					name: "Hide",
					icon: "delete",
					toggled: false,
					viewable: !readOnly
				}
			];
		}

		case "event": {
			const canManageEvents = user.applications
				&& user.applications.find(app => app.appId === "events-app")
				&& user.applications.find(app => app.appId === "events-app").permissions
				&& user.applications.find(app => app.appId === "events-app").permissions.includes("manage");
			const canShareEvents = user.applications
				&& user.applications.find(app => app.appId === "events-app")
				&& user.applications.find(app => app.appId === "events-app").permissions
				&& user.applications.find(app => app.appId === "events-app").permissions.includes("share");
			return [
				{
					name: "Report",
					icon: "description",
					toggled: false,
					viewable: !readOnly && hasReports
				},
				{
					name: isPublic && !canShareEvents ? "Shared" : "Share",
					icon: "share",
					toggled: sharedWith.length > 0,
					disabled: isPublic && !canShareEvents,
					viewable: !readOnly && canShareEvents
				},
				{
					name: "Edit",
					icon: "edit",
					toggled: false,
					viewable: !readOnly && canManageEvents
				},
				{
					name: "Delete",
					icon: "delete",
					toggled: false,
					viewable: !readOnly && entity.ownerOrg === user.orgId && canManageEvents 
				}
			];
		}
		case "facility": {
			const buttons = actions.map(action => {
				switch (action.name.toLowerCase()) {
					case "edit":
						return {
							name: "Edit",
							icon: "edit",
							toggled: false,
							viewable: !readOnly && user.integrations
								&& user.integrations.find(int => int.intId === entity.feedId)
								&& user.integrations.find(int => int.intId === entity.feedId).permissions
								&& user.integrations.find(int => int.intId === entity.feedId).permissions.includes("manage")
						};
					case "hide":
						return {
							name: "Hide",
							icon: "delete",
							toggled: false,
							viewable: !readOnly 
						};
					case "pin to": {
						return {
							name: "Pin To",
							icon: "star",
							toggled: false,
							viewable: !readOnly 
						};
					}
					case "delete": {
						return {
							name: "Delete",
							icon: "delete",
							toggled: false,
							viewable: !readOnly 
						};
					}
					default:
						break;
				}
			});

			return buttons;
		}
		default:
			break;
	}
};

export default getButtons;
