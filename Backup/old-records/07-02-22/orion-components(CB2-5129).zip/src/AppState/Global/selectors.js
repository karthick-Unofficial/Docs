export const globalState = state => state.appState.global;
export const trackHistoryDuration = state => state.appState.global.trackHistory.duration;