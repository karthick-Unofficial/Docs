export { default as BaseWidget } from "./BaseWidget";
