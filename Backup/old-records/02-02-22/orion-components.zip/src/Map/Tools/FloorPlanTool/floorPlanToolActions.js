export { setCoordinates } from "../../Layers/FloorPlan/floorPlanActions";
