import { connect } from "react-redux";
import Spotlight from "./Spotlight";
const mapStateToProps = state => {
	const { mapRef } = state.mapState.baseMap;
	return { map: mapRef };
};

const SpotlightContainer = connect(mapStateToProps)(Spotlight);

export default SpotlightContainer;
